import gallery_1 from "./gallery1.jpg";
import image_6 from "./image6.jpg";
import image_2 from "./image2.jpg";
import image_3 from "./image3.jpg";
import image_4 from "./image4.jpg";
import image_5 from "./image5.jpg";
import gallery_2 from "./gallery2.jpg";
import gallery_3 from "./gallery3.jpg";
import gallery_4 from "./gallery4.jpg";
import step1 from "./Roman.jpeg";


export const assets = {
    gallery_1,
    gallery_2,
    gallery_3,
    gallery_4,
    image_2,
    image_3,
    image_4,
    image_5,
    image_6,
    step1
}